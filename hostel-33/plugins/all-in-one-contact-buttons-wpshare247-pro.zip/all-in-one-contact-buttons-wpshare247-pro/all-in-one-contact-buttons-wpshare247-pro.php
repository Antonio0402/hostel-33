<?php
/**
 * Plugin Name: Contact buttons Pro - WPSHARE247
 * Plugin URI: https://wpshare247.com/
 * Description: Custom new Icons - Floating click to contact buttons All-In-One
 * Version: 1.0
 * Author: Wpshare247.com
 * Author URI: https://wpshare247.com
 * Text Domain: ws247-aio-pro
 * Domain Path: /languages/
 * Requires at least: 4.9
 * Requires PHP: 5.6
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), false);
$plugin_version = $plugin_data['Version'];

define( 'WS247_AIO_PRO_VER', $plugin_version );
define( 'WS247_AIO_PRO', __FILE__ );
define( 'WS247_AIO_PRO_PLUGIN_DIR', untrailingslashit( dirname( WS247_AIO_PRO ) ) );
define( 'WS247_AIO_PRO_PLUGIN_INC_DIR', WS247_AIO_PRO_PLUGIN_DIR . '/inc' );  
require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/define.php';
require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/class.helper.php';
require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/class.setting.page.php';
require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/theme_functions.php';

