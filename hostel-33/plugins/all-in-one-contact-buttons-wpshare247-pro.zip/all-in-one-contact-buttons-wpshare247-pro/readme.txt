﻿=== Plugin Name ===
Contributors: wpshare247, website366
Donate link: https://paypal.me/auvuonle/5
Tags: call button, quick call button, call now button, contact all in one, icon, hotline, facebook, zalo, messenger, google map, email
Requires at least: 4.9
Tested up to: 6.6.2
Requires PHP: 5.6
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Floating click to contact buttons All-In-One

Cho phép custom icon từ plugin all-in-one-contact-buttons-wpshare247

== Description ==
Xem plugin all-in-one-contact-buttons-wpshare247

**Liên hệ - Contact Us**

Professional website design - Thiết kế website chuyên nghiệp: [tbay.vn](https://tbay.vn)
Web design - Thiết kế web trọn gói: [website366.com](https://website366.com)
Wordpress Share - Học wordpress: [wpshare247.com](https://wpshare247.com)

== Installation ==

1. Tải thư mục `all-in-one-contact-buttons-wpshare247-pro` vào đường dẫn `/wp-content/plugins/`
2. Kích hoạt từ menu **Plugins** (**Plugins > Installed Plugins**).

Tìm **Cấu hình Aio liên hệ** hoặc **Configure Aio Contact** menu trong WooCommerce.

== Screenshots ==

1. screenshot-1.png

== Changelog ==

= 1.0 =

* Publishing plugin

