jQuery(document).ready(function(e) {
	ws247_aio_pro_add_new_icon_btn();
	ws247_aio_pro_del_icon_btn();
	ws247_aio_pro_sortable();
	ws247_aio_pro_preview_action();


	var slider_id = '#wpshare247-slider-icons_border_radius';
	jQuery( slider_id ).slider({
		range: "max",
		min: jQuery( slider_id ).data('min'),
		max: jQuery( slider_id ).data('max'),
		step: 1,
		value: jQuery( slider_id ).data('value'),
	  	slide: function( event, ui ) {
	  		var v = ui.value;
	  		var e = event.target;
	  		jQuery( jQuery(e).prev() ).val(v);
	  		jQuery( jQuery(e).next().find('span.m') ).text(v);
	  		//console.log(event); console.log(ui);
	  		jQuery("#ft-contact-icons .item .icon").css("border-radius", v+"px");
	  	}
	});
});

function ws247_aio_pro_preview_action(){
	//----------------
	jQuery("#Ws247_aio_ct_button_hide_icons").click(function(event) {
		if( jQuery(this).is(":checked") ){
			jQuery("#ws247-aio-ct-button-show-all-container").hide();
		}else{
			jQuery("#ws247-aio-ct-button-show-all-container").show();
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_hide_text_icons").click(function(event) {
		if( jQuery(this).is(":checked") ){
			jQuery("#ft-contact-icons").addClass('text-is-hide');
		}else{
			jQuery("#ft-contact-icons").removeClass('text-is-hide');
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_icon_text_on_left").click(function(event) {
		if( jQuery(this).is(":checked") ){
			jQuery("#ft-contact-icons-out-m").addClass('ft-icon-left');
		}else{
			jQuery("#ft-contact-icons-out-m").removeClass('ft-icon-left');
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_is_hide_first").click(function(event) {
		if( jQuery(this).is(":checked") ){
			jQuery("#ws247-aio-ct-button-show-all-icon").removeClass('hide-me');
			jQuery("#ft-contact-icons").removeClass('active');
			
		}else{
			jQuery("#ws247-aio-ct-button-show-all-icon").addClass('hide-me');
			jQuery("#ft-contact-icons").addClass('active');
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_hide_shake_hotline").click(function(event) {
		if( jQuery(this).is(":checked") ){
			jQuery("#phonering-alo-phoneIcon").hide();
		}else{
			jQuery("#phonering-alo-phoneIcon").show();
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_shake_hotline_pos").change(function(event) {
		var v = jQuery(this).val();

		if( v == 2 ){
			jQuery("#ws247-aio-ct-button-hl").addClass('hotline-on-right');
		}else{
			jQuery("#ws247-aio-ct-button-hl").removeClass('hotline-on-right');
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_icons_styles").change(function(event) {
		var v = jQuery(this).val();
		var clss = 'ws247-aio-pro-styles-'+v;

		jQuery("#ws247-aio-ct-button-show-all-container")
		.removeClass('ws247-aio-pro-styles-1 ws247-aio-pro-styles-2 ws247-aio-pro-styles-');

		jQuery("#ws247-aio-ct-button-show-all-container").addClass(clss);
	});

	

	//----------------
	jQuery("#Ws247_aio_ct_button_icons_pos").change(function(event) {
		var v = jQuery(this).val();

		if( v == 1 ){
			jQuery("#ft-contact-icons").addClass('contact-icons-right');
		}else{
			jQuery("#ft-contact-icons").removeClass('contact-icons-right');
		}
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_shake_hotline_bottom").keyup(function(event) {
		var v = jQuery(this).val();
		jQuery("#ws247-aio-ct-button-hl .phonering-alo-phone")
		.css('bottom', v+"px");
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_icons_bottom").keyup(function(event) {
		var v = 1*jQuery(this).val();
		if(v==0){
			jQuery(".show-all-icon, #ft-contact-icons").removeAttr('style');
		}else{
			jQuery(".show-all-icon, #ft-contact-icons")
			.css('bottom', v+"px");
		}
		
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_container_style").change(function(event) {
		var v = jQuery(this).val();
		jQuery("#ft-contact-icons-out-m")
		.removeClass('ft-pn-s ft-pn-s0 ft-pn-s1 ft-pn-s2 ft-pn-s3 ft-pn-s4 ft-pn-s5');
		
		jQuery("#ft-contact-icons-out-m").addClass(v);
		if(v=='ft-pn-sn'){
			var color_1 = jQuery("#Ws247_aio_ct_button_ft_color_1").val();
			var color_2 = jQuery("#Ws247_aio_ct_button_ft_color_2").val();
			jQuery("#ft-contact-icons-out-m")
			.css('background-image', 'linear-gradient(120deg, '+color_1+' 0%, '+color_2+' 100%)');
		}else{
			jQuery("#ft-contact-icons-out-m").removeAttr('style');
		}
		
	});

	//----------------
	jQuery("#Ws247_aio_ct_button_icons_animation").change(function(event) {
		var v = jQuery(this).val();

		jQuery("#ft-contact-icons-out-m")
		.removeClass( jQuery(this).data('cl'));
		
		jQuery("#ft-contact-icons-out-m").addClass(v);
	});

	jQuery('.tr-icon-group input[type="checkbox"]').click(function(event) {
		var id = jQuery(this).attr("id");
			id = id.replace("Ws247_aio_ct_button_hide_", "");
			id = id.replace("_hide", "");
		if( jQuery(this).is(":checked") ){
			jQuery("#ft-contact-icons-out-m #"+id).hide();
		}else{
			jQuery("#ft-contact-icons-out-m #"+id).show();
		}
	});

	
	//----------------
	jQuery('.colorpicker').wpColorPicker({
	    change: function (event, ui) {
	        var element = event.target;
	        var color = ui.color.toString();
	        var id = element.id;
	        console.log(id);

	        if(id=='Ws247_aio_ct_button_text_color'){
	        	jQuery("#ft-contact-icons li span.ab label, #ft-contact-icons .item span.ab label")
	        	.css("color", color);
	        }
	    },
	    clear: function (event) {
	        var element = jQuery(event.target).siblings('.wp-color-picker')[0];
	        var color = '';

	        if (element) {
	            //console.log('xoa1111');
	        }
	    }
	});

	//----------------
	jQuery('.custom-color-bg').wpColorPicker({
	    change: function (event, ui) {
	        var element = event.target;
	        var color = ui.color.toString();
	        var id = element.id;
	        console.log(id);

	        if(id=='Ws247_aio_ct_button_ft_color_1'){
	        	color_1 = color;
	        	color_2 = jQuery("#Ws247_aio_ct_button_ft_color_2").val();
	        }else{
	        	color_2 = color;
	        	color_1 = jQuery("#Ws247_aio_ct_button_ft_color_1").val();
	        }

	        jQuery("#ft-contact-icons-out-m")
	        	.css('background-image', 'linear-gradient(120deg, '+color_1+' 0%, '+color_2+' 100%)');
	       	
	    },
	    clear: function (event) {
	        var element = jQuery(event.target).siblings('.wp-color-picker')[0];
	        var color = '';

	        if (element) {
	            //console.log('xoa1111');
	        }
	    }
	});
	///----------------
}

function ws247_aio_pro_add_new_icon_btn(){
	jQuery("#dialog-ws247-aio-pro-icons #js-ajx-add-icon-pro").click(function(event) {
		var active_len = jQuery("#dialog-ws247-aio-pro-icons .icon-add-new.current").length;
		if(active_len){
			var current_icon = jQuery("#dialog-ws247-aio-pro-icons .icon-add-new.current").get(0);
			var name = jQuery(current_icon).data('name');
			var font_i = jQuery(current_icon).html();
			var link = jQuery("#ws247-aio-pro-icon-link").val();
			var txt = jQuery("#ws247-aio-pro-icon-text").val();
			var hide = ( jQuery("#ws247-aio-pro-icon-checkbox").is(":checked") ) ? 'on' : '';

			jQuery.ajax({
                url: ws247_aio_pro_ajax_url,
                type: 'POST',
                data:  {
                            action: "ws247_aio_pro_add_new_icon_btn",
                            name : name,
                            font_i : font_i,
                            link : link,
                            txt : txt,
                            hide : hide
                        },
                dataType: 'json',
                success: function(data, textStatus, jqXHR){ 
                    //console.log(data); //return false;
                    //jQuery("#dialog-ws247-aio-pro-icons .fancybox-close-small").click();
                    location.reload();
                },
                error: function(jqXHR, textStatus, errorThrown){
                
                }          
            });

		}else{
			alert('Chọn 1 icon để thêm');
		}
		return false;
	});
}

function ws247_aio_pro_del_icon_btn(){
	jQuery(".js-ajax-aio-ct-pro-del").click(function(event) {
		var id = jQuery(this).data('id');
		if(id){
			jQuery.ajax({
                url: ws247_aio_pro_ajax_url,
                type: 'POST',
                data:  {
                            action: "ws247_aio_pro_del_icon_btn",
                            id : id
                        },
                dataType: 'json',
                success: function(data, textStatus, jqXHR){ 
                    //console.log(data); //return false;
                    //jQuery("#dialog-ws247-aio-pro-icons .fancybox-close-small").click();
                    location.reload();
                },
                error: function(jqXHR, textStatus, errorThrown){
                
                }          
            });

		}else{
			alert('Chọn 1 icon để thêm');
		}
		return false;
	});
}

function ws247_aio_pro_sortable(){
	jQuery( "#ws247-aio-pro-table-sortcontainer" ).sortable({
			update: function(e, ui) {
				var sortable_id = jQuery(this).attr("id");
				var s_order = jQuery('#'+sortable_id).sortable('toArray').toString();
				jQuery.ajax({
					url: ws247_aio_pro_ajax_url,
					type: 'POST',
					data:  {
								action: "ws247_aio_pro_sortable",
								s_order : s_order
							},
					dataType: 'json',
					success: function(data, textStatus, jqXHR){ //console.log(data); //return false;
						//jQuery("#quote_qqfs_steps .spinner").removeClass("is-active");
						location.reload();
					},
					error: function(jqXHR, textStatus, errorThrown){
					
					}          
				});
			}
		}).disableSelection();
}