<?php 
$arr_icons = Ws247_aio_pro::class_get_option('list_icons');
if($arr_icons):
    foreach ($arr_icons as $key => $icon) {
        $name = $icon['name'];
        $font_i = $icon['font_i'];
        $link = $icon['link'];
        $txt = $icon['txt'];
        $hide = $icon['hide'];

        $id_link = $key.'_link';
        $id_txt = $key.'_txt';
        $id_hide = $key.'_hide';

        $tr_id = "aioprosortable-".$key;
        ?>
        <tr id="<?php echo $tr_id; ?>" data-key="<?php echo $key; ?>" valign="top" class="tr-icon-group tr-pro-icon-custom">
            <th scope="row">
                <span class="dashicons"><?php echo $font_i; ?></span> <?php esc_html_e($name, WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?>
            </th>
            <td>
                <input placeholder="https://" type="text" id="<?php echo $id_link; ?>" name="<?php echo $key; ?>[]" value="<?php echo esc_attr($link); ?>" />

                <input placeholder="" type="text" id="<?php echo $id_txt; ?>" name="<?php echo $key; ?>[]" value="<?php echo esc_attr($txt); ?>" />

                <input <?php if($hide=='on') echo 'checked'; ?> type="checkbox" id="<?php echo $id_hide; ?>" name="<?php echo $key; ?>[]" /><label for="<?php echo $id_hide; ?>"><?php esc_html_e("Icon hide", WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?></label>
                <a href="#" data-id="<?php echo $tr_id; ?>" class="js-ajax-aio-ct-pro-del">Xóa</a>
                <br/>
                <small></small>
            </td>
            </td>
        </tr>
        <?php
    }
endif;
?>