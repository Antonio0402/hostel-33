<table id="tab_pro_general" class="form-table aeiwooc-tab active">
    <h3 style="margin:0;color:#0055ab;"><span class="dashicons dashicons-arrow-right-alt"></span> AOI Wpshare247 PRO</h3>
    
    <tr valign="top" class="tr-icon-group">
        <th scope="row">
            <span class="dashicons dashicons-admin-generic"></span><?php esc_html_e('Cấu hình', WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?>
        </th>
        <td>
            <a href="<?php echo admin_url('admin.php?page=ws247-aio-ct-button-options'); ?>">Nhấp vào đây</a>
        </td>
    </tr>

    <tr valign="top" class="tr-icon-group">
        <th scope="row">
            <span class="dashicons dashicons-admin-generic"></span><?php esc_html_e('Tài liệu', WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?>
        </th>
        <td>
            <a target="_blank" href="<?php echo WS247_AIO_PRO_DOWNLOAD_URL; ?>">Tài liệu Document</a>
        </td>
    </tr>      
    
</table>