<tr valign="top" class="contact-buttons-wpshare247-pro-extra">
    <th scope="row">
        <?php esc_html_e("Kiểu hiển thị", WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?>
    </th>
    <td>
        <?php 
        $field_name = 'icons_styles'; 
        $field = Ws247_aio_ct_button::create_option_prefix($field_name);
        $icons_styles = Ws247_aio_ct_button::class_get_option($field_name);
        ?>
        <select id="<?php echo esc_html($field); ?>" name="<?php echo esc_html($field); ?>">
            <option value=""><?php esc_html_e("Mặc định", WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?></option>
            <option <?php if($icons_styles=='1') echo 'selected'; ?> value="1"><?php esc_html_e("Kiểu 1", WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?></option>
            <option <?php if($icons_styles=='2') echo 'selected'; ?> value="2"><?php esc_html_e("Kiểu 2", WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?></option>
            
        </select>
    </td>
</tr>

<tr valign="top" class="contact-buttons-wpshare247-pro-extra">
    <th scope="row">
        <?php esc_html_e("Bo góc icon", WS247_AIO_CT_BUTTON_TEXTDOMAIN); ?>
    </th>
    <td>
        <?php 
        $field_name = 'icons_border_radius'; 
        $field = Ws247_aio_ct_button::create_option_prefix($field_name);
        $boder_radius = Ws247_aio_ct_button::class_get_option($field_name);
        if( !($boder_radius >= 0))  $boder_radius = 25;
        $min = 0;
        $max = 50;
        $value = $boder_radius;
        ?>
        <div style="max-width: 200px;">
            <input type="hidden" id="<?php echo esc_html($field); ?>" name="<?php echo esc_html($field); ?>" value="<?php echo esc_html($boder_radius); ?>">
            <div id="wpshare247-slider-icons_border_radius" data-min="<?php echo $min; ?>" data-max="<?php echo $max; ?>" data-value="<?php echo $value; ?>"></div>
            <div class="border-label" style="display: flex; margin-top: 5px;">
                <span class="f">0</span>
                <span class="m" style="width: 90%; text-align: center;"><?php echo $boder_radius; ?></span>
                <span class="e">50</span>px
            </div>
        </div>
        
    </td>
</tr>