<tr valign="top">
    <th scope="row" style="padding-top:0; padding-bottom:0;" colspan="2">
        <div style="color: #fff; padding: 10px; margin-bottom: 10px; background: #FF5722;">
            Bạn đang sử dụng bản <a style="color: #fff;" target="_blank" href="<?php echo WS247_AIO_PRO_DOWNLOAD_URL; ?>">PRO</a>
        </div>
    </th>
</tr>