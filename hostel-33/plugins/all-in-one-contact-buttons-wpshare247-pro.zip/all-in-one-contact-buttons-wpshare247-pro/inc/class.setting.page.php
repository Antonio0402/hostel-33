<?php
if (!class_exists('Ws247_aio_pro')):
  class Ws247_aio_pro
  {
    const FIELDS_GROUP = 'Ws247_aio_pro-fields-group';
    const REL_PLUGIN = 'all-in-one-contact-buttons-wpshare247';
    private $slug, $option_group, $rel_plugin, $setting_page_url, $setting_rel_url;
    /**
     * Constructor
     */
    function __construct()
    {
      if (is_admin()):
        $this->slug = WS247_AIO_PRO_SETTING_PAGE_SLUG;
        $this->option_group = self::FIELDS_GROUP;
        $this->rel_plugin = self::REL_PLUGIN;
        $this->setting_page_url = admin_url('admin.php?page=' . $this->slug);
        $this->setting_rel_url = admin_url('admin.php?page=ws247-aio-ct-button-options');
        add_action('admin_head', array($this, 'admin_head'));
        add_action('admin_menu',  array($this, 'add_setting_page'));
        add_action('admin_init', array($this, 'register_plugin_settings_option_fields'));
        add_action('admin_enqueue_scripts', array($this, 'register_admin_css_js'));
        add_filter('plugin_action_links', array($this, 'add_action_link'), 999, 2);

        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('activated_plugin', array($this, 'activated_plugin'), 10, 2);

        add_action('wp_ajax_ws247_aio_pro_add_new_icon_btn', array($this, 'ws247_aio_pro_add_new_icon_btn'));
        add_action('wp_ajax_nopriv_ws247_aio_pro_add_new_icon_btn', array($this, 'ws247_aio_pro_add_new_icon_btn'));

        add_action('wp_ajax_ws247_aio_pro_del_icon_btn', array($this, 'ws247_aio_pro_del_icon_btn'));
        add_action('wp_ajax_nopriv_ws247_aio_pro_del_icon_btn', array($this, 'ws247_aio_pro_del_icon_btn'));

        add_action('ws247_aio_tr_before', array($this, 'ws247_aio_tr_before'));
        add_action('ws247_aio_tr_after', array($this, 'ws247_aio_tr_after'));

        add_action('ws247_aio_ct_add_icons', array($this, 'ws247_aio_ct_add_icons'));

        add_action('wp_ajax_ws247_aio_pro_sortable', array($this, 'ws247_aio_pro_sortable'));
        add_action('wp_ajax_nopriv_ws247_aio_pro_sortable', array($this, 'ws247_aio_pro_sortable'));

        add_filter('admin_body_class', array($this, 'admin_body_class'));

        add_filter('ws247_aio_ct_btn_add_id', array($this, 'ws247_aio_ct_btn_add_id'), 10, 1);

        add_filter('ws247_aio_ct_tbody_sortcontainer', array($this, 'ws247_aio_ct_tbody_sortcontainer'), 10, 1);


        add_action('ws247_aio_ct_icons_group_after', array($this, 'ws247_aio_ct_icons_group_after'));

        add_filter('ws247_aio_register_field', array($this, 'ws247_aio_register_field'), 10, 1);

        $this->form_submit();
        $this->admin_icons_display();
      endif;

      add_filter('ws247_aio_ct_arr_items', array($this, 'add_arr_icons'), 10, 1);
    }

    public function ws247_aio_ct_btn_add_id($btn_add_id)
    {
      return $btn_add_id . '-pro';
    }

    public function ws247_aio_ct_tbody_sortcontainer($tbody_sortcontainer)
    {
      return 'ws247-aio-pro-table-sortcontainer';
    }

    public function admin_icons_display()
    {
      if (isset($_GET['page'])) {
        if ($_GET['page'] == 'ws247-aio-ct-button-options'):
          add_action('admin_enqueue_scripts', function () {
            //Css
            wp_enqueue_style(WS247_AIO_CT_BUTTON_PREFIX . 'aio_ct_button.css', WS247_AIO_CT_BUTTON_PLUGIN_INC_ASSETS_URL . '/aio_ct_button.css', false, WS247_AIO_CT_BUTTON_VER);

            wp_enqueue_script(WS247_AIO_CT_BUTTON_PREFIX . 'aio_ct_button', WS247_AIO_CT_BUTTON_PLUGIN_INC_ASSETS_URL . '/aio_ct_button.js', array('jquery'), WS247_AIO_CT_BUTTON_VER, true);

            wp_enqueue_style(WS247_AIO_PRO_PREFIX . 'aio_ct_pro_button.css', WS247_AIO_PRO_PLUGIN_INC_ASSETS_URL . '/aio_ct_pro_button.css', false, WS247_AIO_CT_BUTTON_VER);

            //fontawesome-free-6.6.0
            wp_enqueue_style(WS247_AIO_PRO_PREFIX . 'fontawesome-free-6.6.0_css', WS247_AIO_CT_BUTTON_PLUGIN_INC_ASSETS_URL . '/js/fontawesome-free-6.6.0/css/all.min.css', false, '6.6.0');
          });

          add_action('admin_footer', array('WS247_aio_ct_button_Theme', 'wle_contact_icons_display'));
        endif;
      }
    }

    public function admin_body_class($classes)
    {
      $classes .= ' wp247-aio-pro-enable';
      return $classes;
    }

    static function is_has_rel_plugin()
    {
      include_once(ABSPATH . 'wp-admin/includes/plugin.php');
      if (is_plugin_active(self::REL_PLUGIN . '/' . self::REL_PLUGIN . '.php')) {
        return true;
      }
      return false;
    }

    public function is_activated_rel_plugin()
    {
      include_once(ABSPATH . 'wp-admin/includes/plugin.php');
      if (is_plugin_active($this->rel_plugin . '/' . $this->rel_plugin . '.php')) {
        return true;
      }
      return false;
    }

    public function activated_plugin($plugin, $network_activation)
    {
      if ($plugin == plugin_basename(WS247_AIO_PRO)) {
        if ($this->is_activated_rel_plugin()) {
          exit(wp_redirect($this->setting_rel_url));
        } else {
          exit(wp_redirect(admin_url('plugin-install.php?s=' . $this->rel_plugin . '&tab=search&type=term')));
        }
      }
    }

    public function admin_head()
    {
?>
      <link rel="stylesheet" href="https://code.jquery.com/ui/1.14.0/themes/base/jquery-ui.css">
      <script type="text/javascript">
        var ws247_aio_pro_ajax_url = '<?php echo admin_url('admin-ajax.php'); ?>';
      </script>
<?php
    }

    public function add_action_link($links, $file)
    {
      $plugin_file = basename(dirname(WS247_AIO_PRO)) . '/' . basename(WS247_AIO_PRO, '');
      if ($file == $plugin_file) {
        $setting_link = '<a href="' . $this->setting_page_url . '">' . __('Settings') . '</a>';
        array_unshift($links, $setting_link);
      }
      return $links;
    }

    public function register_admin_css_js()
    {
      wp_enqueue_style('wp-color-picker');
      wp_enqueue_script('jquery-ui-sortable');
      wp_enqueue_script('jquery-ui-slider');

      wp_enqueue_style(WS247_AIO_PRO_PREFIX . 'admin_wpshare247.css', WS247_AIO_PRO_PLUGIN_INC_ASSETS_URL . '/admin_wpshare247.com.css', false, WS247_AIO_PRO_VER);

      wp_enqueue_script(WS247_AIO_PRO_PREFIX . 'admin_js', WS247_AIO_PRO_PLUGIN_INC_ASSETS_URL . '/admin_aio_ct_pro_button.js', array('jquery'), '1.0');
    }

    public function add_setting_page()
    {
      add_submenu_page(
        'options-general.php',
        __("Setting", WS247_AIO_PRO_TEXTDOMAIN),
        __("Wp247 Aio PRO", WS247_AIO_PRO_TEXTDOMAIN),
        'manage_options',
        $this->slug,
        array($this, 'the_content_setting_page')
      );
    }

    public function load_textdomain()
    {
      load_plugin_textdomain(WS247_AIO_PRO_TEXTDOMAIN, false, dirname(plugin_basename(WS247_AIO_PRO)) . '/languages/');
    }

    static function create_option_prefix($field_name)
    {
      return WS247_AIO_PRO_PREFIX . $field_name;
    }

    public function get_option($field_name)
    {
      return get_option(WS247_AIO_PRO_PREFIX . $field_name);
    }

    static function class_get_option($field_name)
    {
      return get_option(WS247_AIO_PRO_PREFIX . $field_name);
    }

    public function register_field($field_name)
    {
      register_setting($this->option_group, WS247_AIO_PRO_PREFIX . $field_name);
    }

    public function register_plugin_settings_option_fields()
    {
      /***
       ****register list fields
       ****/
      $arr_register_fields = array(
        //-------------------------------general tab
        ''
      );

      if ($arr_register_fields) {
        foreach ($arr_register_fields as $key) {
          $this->register_field($key);
        }
      }
    }


    public function ws247_aio_register_field($arr_register_fields)
    {
      $arr_f = array(
        'icons_styles',
        'icons_border_radius'
        //'your_name_field'
      );
      if ($arr_f) {
        foreach ($arr_f as $f) {
          $arr_register_fields[] = $f;
        }
      }
      return $arr_register_fields;
    }

    public function the_content_setting_page()
    {
      require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/option-form-template.php';
    }

    public function ws247_aio_ct_add_before()
    {
      require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/icons-before.php';
    }

    public function ws247_aio_ct_add_after()
    {
      require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/icons-after.php';
    }

    public function ws247_aio_ct_add_icons()
    {
      $list_icons_sortable = self::get_option('list_icons_sortable');
      if (empty($list_icons_sortable)) {
        require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/custom-icons.php';
      }
    }

    public function ws247_aio_tr_before()
    {
      require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/ws247_aio_tr_before.php';
    }

    public function ws247_aio_tr_after()
    {
      require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/ws247_aio_tr_after.php';
    }

    public function ws247_aio_ct_icons_group_after()
    {
      require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/ws247_aio_ct_icons_group_after.php';
    }


    public function form_submit()
    {
      if (isset($_POST['option_page'])) {
        if ($_POST['option_page'] == 'Ws247_aio_ct_button-fields-group') {
          $field_name = 'list_icons';

          $arr_icons = self::get_option($field_name);
          if (!is_array($arr_icons)) return false;

          if (count($arr_icons)) {
            foreach ($arr_icons as $key => $icon) {
              $icon_post = $_POST[$key];
              $icon['link'] = isset($icon_post[0]) ? $icon_post[0] : '';
              $icon['txt'] = isset($icon_post[1]) ? $icon_post[1] : '';
              $icon['hide'] = isset($icon_post[2]) ? $icon_post[2] : '';
              $arr_icons[$key] = $icon;
            }
            update_option(WS247_AIO_PRO_PREFIX . $field_name, $arr_icons, false);
          }
        }
      }
    }

    public function ws247_aio_pro_add_new_icon_btn()
    {
      $arr_response = array();

      //_REQUEST
      $name = $_REQUEST['name'];
      $font_i = $_REQUEST['font_i'];
      $link = $_REQUEST['link'];
      $txt = $_REQUEST['txt'];
      $hide = $_REQUEST['hide'];

      //_ACTION
      $icon_id = uniqid(sanitize_title($name) . '_');
      $icon = array(
        'name' => $name,
        'font_i' => str_replace("\\", "", $font_i),
        'link' => $link,
        'txt' => $txt,
        'hide' => $hide
      );

      $field_name = 'list_icons';

      $arr_icons = self::get_option($field_name);
      if (!is_array($arr_icons)) {
        $arr_icons = array();
      }

      $arr_icons[$icon_id] = $icon;
      update_option(WS247_AIO_PRO_PREFIX . $field_name, $arr_icons, false);


      $field_name = 'list_icons_sortable';
      $list_icons_sortable = self::get_option($field_name);
      if (!empty($list_icons_sortable)) {
        $list_icons_sortable[] = $icon_id;
        update_option(WS247_AIO_PRO_PREFIX . $field_name, $list_icons_sortable, false);
      }

      //_RESPONSE
      $arr_response = array(
        'res' => 1
      );
      wp_send_json($arr_response);
      die();
    }

    public function ws247_aio_pro_del_icon_btn()
    {
      $arr_response = array();

      //_REQUEST
      $id = $_REQUEST['id'];

      //_ACTION
      $id = str_replace('aioprosortable-', '', $id);

      $field_name = 'list_icons';
      $arr_icons = self::get_option($field_name);
      if (!is_array($arr_icons)) {
        $arr_icons = array();
      }

      unset($arr_icons[$id]);
      update_option(WS247_AIO_PRO_PREFIX . $field_name, $arr_icons, false);


      $field_name = 'list_icons_sortable';
      $list_icons_sortable = self::get_option($field_name);
      if (!is_array($list_icons_sortable)) {
        $list_icons_sortable = array();
      }

      unset($list_icons_sortable[$id]);
      update_option(WS247_AIO_PRO_PREFIX . $field_name, $list_icons_sortable, false);


      //_RESPONSE
      $arr_response = array(
        'res' => $id
      );
      wp_send_json($arr_response);
      die();
    }

    public function ws247_aio_pro_sortable()
    {
      $arr_response = array();

      //_REQUEST
      $s_order = $_REQUEST['s_order'];

      //_ACTION
      if ($s_order) {
        $s_order = str_replace('aioprosortable-', '', $s_order);
        $arr_sortable = explode(",", $s_order);
      }
      $field_name = 'list_icons_sortable';
      update_option(WS247_AIO_PRO_PREFIX . $field_name, $arr_sortable, false);

      //_RESPONSE
      $arr_response = array(
        'res' => $s_order
      );
      wp_send_json($arr_response);
      die();
    }


    public function add_arr_icons($arr_)
    {
      $new_arr = array();
      $list_icons_sortable = self::get_option('list_icons_sortable');
      $arr_custom_icons = self::get_option('list_icons');
      if (!empty($list_icons_sortable)) {
        foreach ($list_icons_sortable as $key) {
          $key = str_replace(WS247_AIO_CT_BUTTON_PREFIX, '', $key);
          $item = isset($arr_[$key]) ? $arr_[$key] : 0;
          if (is_array($item)) {
            $new_arr[$key] = $item;
          } else {
            $item = isset($arr_custom_icons[$key]) ? $arr_custom_icons[$key] : 0;
            if (is_array($item)) {
              $item['custom'] = 1;
              $new_arr[$key] = $item;
            }
          }
        }
        return $new_arr;
      } else {
        if (!empty($arr_custom_icons)) {  //var_dump($arr_custom_icons);
          foreach ($arr_custom_icons as $key => $item) {
            $item['custom'] = 1;
            $arr_[$key] = $item;
          }
        }
      }

      return $arr_;
    }


    //End class--------------	
  }

  new Ws247_aio_pro();
endif;
