<?php
define( 'WS247_AIO_PRO_PLUGIN_INC_ASSETS_URL', plugins_url('assets', WS247_AIO_PRO ) );
define( 'WS247_AIO_PRO_TEXTDOMAIN', 'ws247-aio-pro' );
define( 'WS247_AIO_PRO_SETTING_PAGE_SLUG', 'ws247-aio-pro-options' );
define( 'WS247_AIO_PRO_PREFIX', 'Ws247_aio_pro_' );
define( 'WS247_AIO_PRO_DOWNLOAD_URL', 'https://wpshare247.com/plugin/all-in-one-contact-buttons-wpshare247-pro' );