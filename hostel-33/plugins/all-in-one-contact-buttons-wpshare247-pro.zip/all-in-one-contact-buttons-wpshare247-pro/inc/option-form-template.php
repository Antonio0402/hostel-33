<div id="wle-libs-admin" class="wrap wle-options">
    <div id="poststuff" class="basic-admin wle-options-area">
        <div class="postbox-container">
            <div class="meta-box-sortables ui-sortable">
                <div class="postbox remove-border">
                    <div id="welcome-panel_bk">
                        <div class="welcome-panel-content">
                            <h2 class="hndle ui-sortable-handle fsz-tt"><?php _e("Ws247 Aio Pro - WPSHARE247", WS247_AIO_PRO_TEXTDOMAIN); ?></h2>
                            <div class="content">
                                <div class="inside">
                                	<?php $lang_code = get_locale(); ?>
                                    <form method="post" action="options.php" class="form-theme-options">
                                        <?php settings_fields( Ws247_aio_pro::FIELDS_GROUP ); ?>
                                        <?php do_settings_sections( Ws247_aio_pro::FIELDS_GROUP ); ?>
                                        <div class="in-form">
                                            <?php 
                                            if(!Ws247_aio_pro::is_has_rel_plugin() || 
                                                !(WS247_AIO_CT_BUTTON_VER >= 1.2) ){
                                                ?>
                                                <a href="<?php echo admin_url('plugin-install.php?s='.Ws247_aio_pro::REL_PLUGIN.'&tab=search&type=term'); ?>">Cài plugin</a> trước khi sử dụng bản PRO
                                                <?php
                                            }else{
                                                require_once WS247_AIO_PRO_PLUGIN_INC_DIR . '/tabs/tab_pro_general.php';
                                            }
     
                                            if(Ws247_aio_pro::is_has_rel_plugin()){
                                                submit_button(); 
                                            }
                                            ?>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>