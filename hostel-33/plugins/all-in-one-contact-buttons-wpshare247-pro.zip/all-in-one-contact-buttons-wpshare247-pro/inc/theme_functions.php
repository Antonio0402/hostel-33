<?php
/**
 * @class   WS247_aio_pro_Theme
 */
 
if( !class_exists('WS247_aio_pro_Theme') ):
	class WS247_aio_pro_Theme{
		/**
		 * Constructor
		 */
		function __construct() {
			$this->init();
		}
		
		public function init(){
			add_action( 'ws247_aio_style', array($this, 'ws247_aio_style'));
			add_action( 'wp_enqueue_scripts', array($this, 'register_scripts'), 99999 );
			add_filter( 'ws247_aio_container_class', array($this, 'ws247_aio_container_class'), 10, 1 );
		}
		public function ws247_aio_style() {

			ob_start();

			//-----------
			$icons_border_radius = (int)Ws247_aio_ct_button::class_get_option('icons_border_radius'); 
			?>
			#ft-contact-icons .item .icon{
				border-radius: <?php echo $icons_border_radius; ?>px;
			}
			<?php
			
			//-----------

			$s_style = ob_get_contents();
			ob_end_clean();

			echo $s_style;
		}

		public function register_scripts() {
			wp_enqueue_style( WS247_AIO_CT_BUTTON_PREFIX.'fontawesome-470', WS247_AIO_CT_BUTTON_PLUGIN_INC_ASSETS_URL . '/js/font-awesome-4.7.0/css/font-awesome.min.css', false, '4.7.0' );
			
			//Css
			wp_enqueue_style( WS247_AIO_PRO_PREFIX.'aio_ct_pro_button.css', WS247_AIO_PRO_PLUGIN_INC_ASSETS_URL . '/aio_ct_pro_button.css', false, WS247_AIO_PRO_VER );
		}

		public function ws247_aio_container_class($custom_class){
			$custom_class .= ' ws247-aio-pro-container';

			$icons_styles = Ws247_aio_ct_button::class_get_option('icons_styles');
			if($icons_styles){
				$custom_class .= ' ws247-aio-pro-styles-'.$icons_styles;
			}

			$icons_border_radius = Ws247_aio_ct_button::class_get_option('icons_border_radius');
			if($icons_border_radius){
				$custom_class .= ' ws247-aio-pro-border-radius-'.$icons_border_radius;
			}

			return $custom_class;
		}

		public function ws247_aio_custom_items(){
			$arr_icons = Ws247_aio_pro::class_get_option('list_icons');

			$items = '';

			if($arr_icons){
				foreach ($arr_icons as $key => $icon) {
					$font_i = $icon['font_i'];
				    $link = $icon['link'];
				    $txt = $icon['txt'];
				    $hide = $icon['hide'];

				    if($link && $hide != 'on'):
				    	$items .= '	<div class="wp247-icon-custom item">';
				    		$items .= '<a href="'.$link.'" target="_blank">
				    						<span class="icon">'.$font_i.'</span>
				    		';
				    		if($txt && $hide !='on'){
				    			$items .= '<span class="ab"><i class="fas fa-caret-left"></i> <label>'.esc_attr($txt).'</label></span>';	
				    		}
							$items .= '</a>';				
						$items .= '	</div>';
				    endif;
				}
			}

			

			$items = apply_filters( 'ws247_aio_pro_custom_items', $items );

			echo $items;
		}
	
	//End class------------------------
	}
	
	//Init
	$WS247_aio_pro_Theme = new WS247_aio_pro_Theme();
	
endif;