<?php

/**
 * Check Plugin is turn on 
 */
function pl_ht33_view_count_is_turn_on()
{
  $turn_off = Hostel33ViewCountPlugin::class_get_option('turn_off');
  if ($turn_off == "") return true;
  return false;
}

/**
 * Get all post types
 */
function pl_ht33_view_count_get_post_type_arr()
{
  $arr_post_type = Hostel33ViewCountPlugin::class_get_option('post_type');
  return $arr_post_type;
}


/**
 * Get post view  
 */
function pl_ht33_view_count_get_post_view($post_id)
{
  $int_view = (int)get_post_meta($post_id, HT33_VIEW_COUNT_META_KEY_POST_TOTAL, true);
  return $int_view;
}

/**
 * Get term view  
 */
function pl_ht33_view_count_get_term_view($term_id)
{
  $int_view = (int)get_term_meta($term_id, HT33_VIEW_COUNT_META_KEY_TERM_TOTAL, true);
  return $int_view;
}

/**
 * Action wp_head 
 */
function pl_ht33_view_count_wp_head()
{
  //Update post view
  if (is_singular() && pl_ht33_view_count_is_turn_on()) {
    $post_type = get_post_type();
    $arr_post_type = pl_ht33_view_count_get_post_type_arr();
    if (in_array($post_type, $arr_post_type)):
      $post_id = get_the_ID();
      $v_post = get_post($post_id);
      if ($v_post) {
        $post_status = $v_post->post_status;
        if ($post_status == 'publish') {
          $int_view = pl_ht33_view_count_get_post_view($post_id) + 1;
          update_post_meta($post_id, HT33_VIEW_COUNT_META_KEY_POST_TOTAL, $int_view, '');
        }
      }
    endif;
  }

  //Update term view
  if (pl_ht33_view_count_is_turn_on()):
    $current_term_id = get_queried_object()->term_id;
    if ($current_term_id) {
      $int_view = pl_ht33_view_count_get_term_view($current_term_id) + 1;
      update_term_meta($current_term_id, HT33_VIEW_COUNT_META_KEY_TERM_TOTAL, $int_view, '');
    }
  endif;
}
add_action('wp_head', 'pl_ht33_view_count_wp_head');

// ADMIN ----------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------
if (is_admin()):
  $arr_post_type = pl_ht33_view_count_get_post_type_arr();

  /**
   * Add post view column 
   */
  function pl_ht33_view_count_columns_head($defaults)
  {
    $defaults[HT33_VIEW_COUNT_META_KEY_POST_TOTAL]  = _n('View', 'Views', 1, HT33_VIEW_COUNT_TEXT_DOMAIN);
    return $defaults;
  }

  /**
   * Get value of post view column 
   */
  function pl_ht33_view_count_columns_content($column_name, $post_ID)
  {
    if ($column_name == HT33_VIEW_COUNT_META_KEY_POST_TOTAL) {
      echo pl_ht33_view_count_get_post_view($post_ID);
    }
  }

  /**
   * Sort post view column 
   */
  function pl_ht33_view_count_columns_sortable()
  {
    $columns[HT33_VIEW_COUNT_META_KEY_POST_TOTAL] = HT33_VIEW_COUNT_META_KEY_POST_TOTAL;
    return $columns;
  }

  /**
   * pre_get_posts post view column 
   */
  function pl_ht33_view_count_pre_get_posts($query)
  {
    $arr_post_type = pl_ht33_view_count_get_post_type_arr();

    if (empty($arr_post_type)) return; // Skip if no post types are configured

    global $pagenow;
    if (!isset($query->query['post_type'])) return; // Make sure post_type exists
    $post_type = $query->quer['post_type'];
    if (in_array($post_type, $arr_post_type) && $pagenow == 'edit.php') {
      if (isset($_REQUEST['orderby']) && !empty($_REQUEST['orderby'])) {
        if ($_REQUEST['orderby']) {
          $meta_key = $_REQUEST['orderby'];
          $order = ($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';

          $query->set('orderby', 'meta_value_num');
          $query->set('order', $order);

          $query->set(
            'meta_query',
            array(
              'relation'    => 'OR',
              array(
                'key' => $meta_key,
                'compare' => 'NOT EXISTS'
              ),
              array(
                'key' => $meta_key,
                'compare' => '>=',
                'value' =>  0
              ),
            )
          );
        }
      }
    }
  }


  if ($arr_post_type) {
    foreach ($arr_post_type as $post_type) {
      $post_type = $post_type . '_';
      if ($post_type == 'post') $post_type = '';
      add_filter('manage_' . $post_type . 'posts_columns', 'pl_ht33_view_count_columns_head', 10);
      add_action('manage_' . $post_type . 'posts_custom_column', 'pl_ht33_view_count_columns_content', 10, 2);
      add_filter('manage_edit-' . $post_type . 'sortable_columns', 'pl_ht33_view_count_columns_sortable');
    }
  }

  /**
   * Sort post reorder
   */
  add_action('pre_get_posts', 'pl_ht33_view_count_pre_get_posts');


  /**
   * Add category view column 
   */
  function pl_ht33_view_count_add_tax_column_head($columns)
  {
    $columns[HT33_VIEW_COUNT_META_KEY_TERM_TOTAL] = _n('View', 'Views', 1, HT33_VIEW_COUNT_TEXT_DOMAIN);;
    return $columns;
  }
  add_filter('manage_edit-category_columns', 'pl_ht33_view_count_add_tax_column_head');

  /**
   * Get value of category view column 
   */
  function pl_ht33_view_count_manage_category_custom_fields($deprecated, $column_name, $term_id)
  {
    if ($column_name == HT33_VIEW_COUNT_META_KEY_TERM_TOTAL) {
      $int_view = pl_ht33_view_count_get_term_view($term_id);
      echo $int_view;
    }
  }
  add_filter('manage_category_custom_column', 'pl_ht33_view_count_manage_category_custom_fields', 10, 3);

endif;
