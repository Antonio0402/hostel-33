<div id="wle-libs-admin" class="wrap wle-options">
  <div id="poststuff" class="basic-admin wle-options-area">
    <div class="postbox-container">
      <div class="meta-box-sortables ui-sortable">
        <div class="postbox remove-border">
          <div id="welcome-panel_bk">
            <div class="welcome-panel-content">
              <h2 class="hndle ui-sortable-handle fsz-tt"><?php _e("Config the view count functionality in posts/pages", HT33_VIEW_COUNT_TEXT_DOMAIN); ?></h2>
              <div class="content">
                <div class="inside">
                  <form method="post" action="options.php" class="form-theme-options">
                    <?php $HT33_VIEW_COUNT_CLASS = HT33_VIEW_COUNT_CLASS; ?>
                    <?php settings_fields($HT33_VIEW_COUNT_CLASS::FIELDS_GROUP); ?>
                    <?php do_settings_sections(HT33_VIEW_COUNT_SETTING_PAGE_SLUG); ?>
                    <div class="in-form">
                      <table class="form-table">
                        <!--List field here .....-->


                        <!-- ........................ -->
                        <tr valign="top">
                          <td id="ht33_view_count_post_type_td">
                            <div>
                              <strong><?php _e("Chose type of post", HT33_VIEW_COUNT_TEXT_DOMAIN); ?></strong>
                            </div>
                            <ul>
                              <!-- Load ajax 'wle_init_load_post_types' -->
                            </ul>
                            <input type="checkbox" id="ht33_view_count_post_type_uncheck">
                            <label for="ht33_view_count_post_type_uncheck"><?php _e('Select/Unselect All', HT33_VIEW_COUNT_TEXT_DOMAIN) ?></label>
                          </td>
                        </tr>

                        <!-- ........................ -->
                        <tr valign="top">
                          <td>
                            <?php
                            $field_name = 'turn_off';
                            $field = HT33_VIEW_COUNT_PREFIX . $field_name;
                            $val = $HT33_VIEW_COUNT_CLASS::class_get_option($field_name);
                            ?>
                            <input <?php checked($val, 'on'); ?> type="checkbox" id="<?php echo $field; ?>" name="<?php echo $field; ?>" />
                            <label for="<?php echo $field; ?>"><?php _e('Pause', HT33_VIEW_COUNT_TEXT_DOMAIN); ?></label>
                          </td>
                        </tr>

                      </table>
                      <?php submit_button('Save Settings'); ?>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>