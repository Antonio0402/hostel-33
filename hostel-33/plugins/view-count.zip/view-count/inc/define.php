<?php
define('HT33_VIEW_COUNT_TEXT_DOMAIN', 'ht33-view-count');
define('HT33_VIEW_COUNT_SETTING_PAGE_SLUG', 'ht33-view-count-setting-page');
define('HT33_VIEW_COUNT_PREFIX', 'ht33_view_count_');
define('HT33_VIEW_COUNT_META_KEY_POST_TOTAL', 'ht33_view_count_post_total');
define('HT33_VIEW_COUNT_META_KEY_TERM_TOTAL', 'ht33_view_count_term_total');
