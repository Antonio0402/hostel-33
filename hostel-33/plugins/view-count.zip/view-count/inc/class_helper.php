<?php
if (!class_exists('Hotel33ViewCountHelper')):
  class Hostel33ViewCountHelper
  {
    public static function load_post_types()
    {
      check_ajax_referer('ht33_view_count_nonce', 'nonce');

      if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json_error('Only POST requests are allowed');
      }

      $saved_post_types = Hostel33ViewCountPlugin::class_get_option('post_type');
      if (!is_array($saved_post_types)) {
        $saved_post_types = array();
      }

      $args = array(
        'show_ui'  => 1,
        'public' => true
      );
      $post_types = get_post_types($args, 'objects');
      $html = '';
      if (!empty($post_types)) {
        foreach ($post_types as $post_type) {
          if ($post_type->name != 'attachment') {
            $checked = in_array($post_type->name, $saved_post_types) ? 'checked' : '';
            $html .= '<li>';
            $html .= '<label>';
            $html .= '<input type="checkbox" name="' . HT33_VIEW_COUNT_PREFIX . 'post_type[]" value="' . esc_attr($post_type->name) . '" ' . $checked . '>';
            $html .= esc_html($post_type->labels->name);
            $html .= '</label>';
            $html .= '</li>';
          }
        }
      }

      wp_send_json_success(array(
        'html' => $html
      ));
      wp_die();
    }
  }
endif;
