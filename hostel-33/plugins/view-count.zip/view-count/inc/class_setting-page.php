<?php
if (!class_exists('Hostel33ViewCountPlugin')):
  class Hostel33ViewCountPlugin
  {
    const FIELDS_GROUP = 'hpc-fields-group';
    // Declare all properties used in the class
    protected $slug;
    protected $option_group;
    function __construct()
    {
      define('HT33_VIEW_COUNT_CLASS', get_class($this));
      $this->slug = HT33_VIEW_COUNT_SETTING_PAGE_SLUG;
      $this->option_group = self::FIELDS_GROUP;
      /**
       * Register our adminPage to the admin_menu action hook.
       */
      add_action('admin_menu', [$this, 'add_setting_page']);
      /**
       * Register our settings to the admin_init action hook.
       */
      add_action('admin_init', [$this, 'register_plugin_settings_option_fields']);
      add_filter('plugin_action_links', array($this, 'add_action_link'), 999, 2);

      // if (is_admin()) {
      add_action('wp_ajax_ht33_view_count_load_post_types', array('Hostel33ViewCountHelper', 'load_post_types'));
      add_action('wp_ajax_nopriv_ht33_view_count_load_post_types', array('Hostel33ViewCountHelper', 'load_post_types'));
      // }
    }

    public function add_action_link($links, $file)
    {
      $plugin_file = basename(HT33_VIEW_COUNT, '.php') . '/' . basename(HT33_VIEW_COUNT, '');
      if ($file == $plugin_file) {
        $setting_link = '<a href="' . admin_url('options-general.php?page=' . HT33_VIEW_COUNT_SETTING_PAGE_SLUG) . '">' . __('Settings') . '</a>';
        array_unshift($links, $setting_link);
      }
      return $links;
    }

    public function add_setting_page(): void
    {
      $menuPageHook = add_options_page(
        'View Count Setting',
        __('View Count', HT33_VIEW_COUNT_TEXT_DOMAIN),
        'manage_options',
        $this->slug,
        [$this, 'show_setting_page']
      );
      add_action('load-' . $menuPageHook, [$this, 'load_backend_assets']);
    }

    public function get_option($field_name)
    {
      return get_option(HT33_VIEW_COUNT_PREFIX . $field_name);
    }

    static function class_get_option($field_name)
    {
      $option = get_option(HT33_VIEW_COUNT_PREFIX . $field_name);

      if ($field_name === 'post_type' && !is_array($option)) {
        return array();
      }

      return $option;
    }


    public function register_field($field_name, $callback_array = NULL): void
    {
      if ($callback_array && (in_array('sanitize_callback', $callback_array) || in_array('default', $callback_array))) {
        register_setting($this->option_group, HT33_VIEW_COUNT_PREFIX . $field_name, $callback_array);
        return;
      }
      register_setting($this->option_group, HT33_VIEW_COUNT_PREFIX . $field_name);
    }

    public function register_plugin_settings_option_fields(): void
    {
      // register our settings
      $this->register_field('post_type');

      $this->register_field('turn_off');
    }

    public function load_backend_assets(): void
    {
      wp_enqueue_style('ht33-view-count-admin-css', plugin_dir_url(HT33_VIEW_COUNT) . 'assets/admin.css', [], '1.0.0', 'all');
      wp_enqueue_script('ht33-view-count-admin-js', plugin_dir_url(HT33_VIEW_COUNT) . '/assets/admin.js', ['jquery'], '1.0.0', true);
      wp_localize_script('ht33-view-count-admin-js', 'ht33_view_count_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'action' => 'ht33_view_count_load_post_types',
        'nonce' => wp_create_nonce('ht33_view_count_nonce'),
      ]);
    }

    public function show_setting_page(): void
    {
      // check user capabilities
      if (! current_user_can('manage_options')) {
        return;
      }

      // check if the user have submitted the settings
      // WordPress will add the "settings-updated" $_GET parameter to the url
      if (isset($_GET['settings-updated'])) {
        // add settings saved message with the class of "updated"
        add_settings_error('ht33-view-count_messages', 'wcp_message', __('Settings Saved', HT33_VIEW_COUNT_TEXT_DOMAIN), 'updated');
      }

      // show error/update messages
      settings_errors('ht33-view-count_messages');


      require_once HT33_VIEW_COUNT_PLUGIN_INC_DIR . '/template-option-form.php';
    }
  }
  new Hostel33ViewCountPlugin();
endif;
