<?php

if (! defined('WP_UNINSTALL_PLUGIN')) {
  exit();
}

function pl_ht33_view_count_delete_plugin()
{
  global $wpdb;

  //Delete option if exist
  global $wpdb;
  $prefix = 'ht33-view-count';
  $plugin_options = $wpdb->get_results("	SELECT `option_name` 
											FROM $wpdb->options 
											WHERE ( `option_name` LIKE '" . $prefix . "%' )
										");
  if ($plugin_options):
    foreach ($plugin_options as $option) {
      delete_option($option->option_name);
    }
  endif;

  //Delete meta post
  $prefix = 'ht33-view-count';
  $postmetas = $wpdb->get_results("	SELECT `meta_id` 
										FROM $wpdb->postmeta 
										WHERE ( `meta_key` LIKE '" . $prefix . "%' )
										");
  if ($postmetas):
    foreach ($postmetas as $postmeta) {
      $wpdb->delete($wpdb->postmeta, array('meta_id' => $postmeta->meta_id));
    }
  endif;

  //Delete post if exist
}

pl_ht33_view_count_delete_plugin();
