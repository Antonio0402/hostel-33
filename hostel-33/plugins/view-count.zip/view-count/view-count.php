<?php

/**
 * Plugin Name: Display view count - hostel-33
 * Plugin URI: https://antonio-doan.tech/
 * Description: Display the total views of all posts, pages and custom post types.
 * Author: Antonio
 * Author URI: https://antonio-doan.tech/
 * Version: 1.0.0
 * Text Domain: ht33-view-count
 * Domain Path: /languages/
 **/

ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!defined('ABSPATH')) {
  exit;
}

define('HT33_VIEW_COUNT', __FILE__);
define('HT33_VIEW_COUNT_PLUGIN_DIR', plugin_dir_path(HT33_VIEW_COUNT));
define('HT33_VIEW_COUNT_PLUGIN_INC_DIR', HT33_VIEW_COUNT_PLUGIN_DIR . 'inc/');
define('HT33_VIEW_COUNT_ASSETS_DIR', HT33_VIEW_COUNT_PLUGIN_DIR . 'assets/');
require_once HT33_VIEW_COUNT_PLUGIN_INC_DIR . '/define.php';
require_once HT33_VIEW_COUNT_PLUGIN_INC_DIR . '/class_setting-page.php';
require_once HT33_VIEW_COUNT_PLUGIN_INC_DIR . '/class_helper.php';
require_once HT33_VIEW_COUNT_PLUGIN_INC_DIR . '/functions.php';
