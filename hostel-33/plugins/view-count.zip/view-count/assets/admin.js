jQuery.noConflict();
(function ($) {
  $(document).ready(function () {
    ht33_view_count_init_load_post_types();

    $("#ht33_view_count_post_type_uncheck").click(function (e) {
      if ($(this).is(":checked")) {
        $("#ht33_view_count_post_type_td ul input[type='checkbox']").prop("checked", true);
      } else {
        $("#ht33_view_count_post_type_td ul input[type='checkbox']").prop("checked", false);
      }
    });

    setTimeout(function () {
      var view_count_post_type_total = $("#ht33_view_count_post_type_td ul input[type='checkbox']").length;
      var view_count_post_type_checked_total = $("#ht33_view_count_post_type_td ul input[type='checkbox']:checked").length;
      if (view_count_post_type_total == view_count_post_type_checked_total) {
        $("#ht33_view_count_post_type_uncheck").prop("checked", true);
      }
    }, 1000);
  });

  function ht33_view_count_init_load_post_types() {
    $.ajax({
      url: ht33_view_count_ajax.ajax_url,
      type: 'POST',
      data: {
        action: ht33_view_count_ajax.action,
        nonce: ht33_view_count_ajax.nonce,
      },
      dataType: 'json',
      success: function (response) {
        if (response.success) {
          if (response.data && response.data.html) {
            $('#ht33_view_count_post_type_td ul').append(response.data.html);
          }
        } else {
          console.error("Error loading post types:", response);
        }
      },
      error: function (xhr, status, error) {
        console.error("AJAX Error:", status, error);
        console.log("Response:", xhr.responseText);
      }
    });
  }
})(jQuery);